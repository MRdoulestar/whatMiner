#ifndef REALLOCARRAY_H
#define REALLOCARRAY_H
#include <stdio.h>

void *
reallocarray_s(void *p, size_t count, size_t size);

#endif
